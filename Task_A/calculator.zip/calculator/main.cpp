#include <iostream>
using namespace std;

int add(int a, int b);
int subtract(int a, int b);

int main() {
    int x = 10, y = 5;
    cout << "Addition: " << add(x, y) << endl;
    cout << "Subtraction: " << subtract(x, y) << endl;
    return 0;
}

int add(int a, int b) {
return a+b;
}

int subtract(int a, int b) {
return a-b;
}
